#main file for WESS app
import dash
from dash import Dash, html, dcc, callback, Input, Output
import plotly.express as px

# Import custom py files
from df_customMethods import *
import map, trendlines, connections

# To change what CSV is used, update filepath in df_custom_methods.py

app = Dash(__name__, use_pages=False, suppress_callback_exceptions=True)
app.layout = html.Div([
    html.H1('Wireless Environmental Sensor System'),
    dcc.Tabs(
        id="tabs",
        value="map",  # Default selected tab
        parent_className='custom-tabs',
        className='custom-tabs-container',
        children=[
            dcc.Tab(label="Map", value="map",
                    className='custom-tab', selected_className='custom-tab--selected'),
            dcc.Tab(label="Trendline", value="trendline",
                    className='custom-tab', selected_className='custom-tab--selected'),
            dcc.Tab(label="Connections", value="connections",
                    className='custom-tab', selected_className='custom-tab--selected')
        ],
    ),
    html.Div(id="tab-content"),
])

@app.callback(
    Output('tab-content', 'children'),
    Input('tabs', 'value')
)

def render_page(tab_value):
    if(tab_value=='map'):
        return map.layout()
    elif(tab_value=='trendline'):
       return trendlines.layout()
    elif(tab_value=='connections'):
        return connections.layout()

map.register_callbacks(app)
trendlines.register_callbacks(app)
connections.register_callbacks(app)

#server = app.server

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=False, port=8050)
